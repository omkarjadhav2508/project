package com.Ecom.project;

import java.sql.SQLException;
import java.util.*;

public class Test {

	public static void main(String[] args) throws SQLException {
		
		
		Admin a= new Admin();
		a.getRegisteredUser();
		Product p=new Product();
		//p.getQuantity();
		
		//System.out.println(t);
	}

}
