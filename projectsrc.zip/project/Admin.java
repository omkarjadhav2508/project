package com.Ecom.project;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;

public class Admin {
	
	LinkedHashMap gq = new LinkedHashMap();
	ArrayList al = null;
	User u= new User(); 
	int qi1,qi2,qi3,qi4,qi5,qi6,qi7,qi8,qi9,qi10;
	Connection congb=null;
	PreparedStatement psgq=null;
	ResultSet rsgq=null;
	int a[]= new int[11];
	
	
	
	PreparedStatement psgru=null;
	ResultSet rsgru=null;
	
	public int AdmingetQuantity(int pid) {
		try {
			congb = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecom", "root", "Root");
			psgq = congb.prepareStatement("select pid, quantity from product");
			rsgq = psgq.executeQuery();
			
			while (rsgq.next()) {

				gq.put(rsgq.getInt(1), rsgq.getInt(2));

			}
			al = new ArrayList(gq.values());

			qi1 = (Integer) al.get(0);
			qi2 = (Integer) al.get(1);
			qi3 = (Integer) al.get(2);
			qi4 = (Integer) al.get(3);
			qi5 = (Integer) al.get(4);
			qi6 = (Integer) al.get(5);
			qi7 = (Integer) al.get(6);
			qi8 = (Integer) al.get(7);
			qi9 = (Integer) al.get(8);
			qi10 = (Integer) al.get(9);
			
			
			a[0]=qi1;
			a[1]=qi2;
			a[2]=qi3;
			a[3]=qi4;
			a[4]=qi5;
			a[5]=qi6;
			a[6]=qi7;
			a[7]=qi8;
			a[8]=qi9;
			a[9]=qi10;
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return a[pid-1];

	}



	public void getRegisteredUser() throws SQLException
	{	
		try
		{
		congb= DriverManager.getConnection("jdbc:mysql://localhost:3306/ecom", "root", "Root");
		
		psgru= congb.prepareStatement("select * from user");
		
		rsgru= psgru.executeQuery();
		
		System.out.println("user id      first name       last name       mobile            email id ");
		System.out.println("=========================================================================");
		
		while(rsgru.next())
		{
			System.out.println(rsgru.getInt(1)+"           "+rsgru.getString(2)+"            "+rsgru.getString(3)+"          "+rsgru.getString(4)+"        "+rsgru.getString(5));
			
		}
		System.out.println("=========================================================================");
		
		}
		
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
		congb.close();
		psgru.close();
		rsgru.close();
		}
	}
}
