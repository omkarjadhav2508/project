package com.Ecom.project;

import java.sql.*;
import java.util.Scanner;

public class User {
	String fName;
	String lName;
	String mobile;
	String mail;
	public void registerUser() throws SQLException {
		
		Connection con = null;
		PreparedStatement ps = null;
		Scanner sc = new Scanner(System.in);
		Product p= new Product();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecom", "root", "Root");
			ps = con.prepareStatement("insert into user(fName,lName,mobile,email) values(?,?,?,?)");
			System.out.println("Please enter below details to register :)");
			System.out.println("Please enter first name");
			fName = sc.next();
			System.out.println("Please enter last name");
			lName = sc.next();
			System.out.println("Please enter mobile number");
			 mobile = sc.next();
			System.out.println("Please enter mail id");
			mail = sc.next();
			ps.setString(1, fName);
			ps.setString(2, lName);
			ps.setString(3, mobile);
			ps.setString(4, mail);
			ps.executeUpdate();
			System.out.print("*************Registration successful*********");
			p.showProducts(p);
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			con.close();
			sc.close();
			ps.close();
		}

	}
	@Override
	public String toString() {
		return "User [fName=" + fName + ", lName=" + lName + ", mobile=" + mobile + ", mail=" + mail + "]";
	}

}
