package com.Ecom.project;

import java.sql.*;

public class UpdateTab {
	Connection utcon = null;
	PreparedStatement uts1 = null;
	PreparedStatement uts2 = null;
	PreparedStatement uts3 = null;
	PreparedStatement uts4 = null;
	PreparedStatement uts5 = null;
	PreparedStatement uts6 = null;
	PreparedStatement uts7 = null;
	PreparedStatement uts8 = null;
	PreparedStatement uts9 = null;
	PreparedStatement uts10 = null;

	public void updateTable(Product p) throws SQLException {

		try {

			utcon = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecom", "root", "Root");

			uts1 = utcon.prepareStatement("update product set quantity = ? where pid=1");
			uts1.setInt(1, p.qi1);

			uts2 = utcon.prepareStatement("update product set quantity = ? where pid=2");
			uts2.setInt(1, p.qi2);

			uts3 = utcon.prepareStatement("update product set quantity = ? where pid=3");
			uts3.setInt(1, p.qi3);

			uts4 = utcon.prepareStatement("update product set quantity = ? where pid=4");
			uts4.setInt(1, p.qi4);

			uts5 = utcon.prepareStatement("update product set quantity = ? where pid=5");
			uts5.setInt(1, p.qi5);

			uts6 = utcon.prepareStatement("update product set quantity = ? where pid=6");
			uts6.setInt(1, p.qi6);

			uts7 = utcon.prepareStatement("update product set quantity = ? where pid=7");
			uts7.setInt(1, p.qi7);

			uts8 = utcon.prepareStatement("update product set quantity = ? where pid=8");
			uts8.setInt(1, p.qi8);

			uts9 = utcon.prepareStatement("update product set quantity = ? where pid=9");
			uts9.setInt(1, p.qi9);

			uts10 = utcon.prepareStatement("update product set quantity = ? where pid=10");
			uts10.setInt(1, p.qi10);

			uts1.execute();
			uts2.execute();
			uts3.execute();
			uts4.execute();
			uts5.execute();
			uts6.execute();
			uts7.execute();
			uts8.execute();
			uts9.execute();
			uts10.execute();

			// System.out.println("Quantity updated into table");
		}

		catch (Exception e) {
			e.printStackTrace();
		}

		finally {
			utcon.close();
			uts1.close();
			uts2.close();
			uts3.close();
			uts4.close();
			uts5.close();
			uts6.close();
			uts7.close();
			uts8.close();
			uts9.close();
			uts10.close();

		}
	}

}
