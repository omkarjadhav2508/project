package com.Ecom.project;


import java.sql.SQLException;
import java.util.*;


public class Test {
	
	public static void main(String[] args) throws SQLException {
		
		Product p= new Product();
		p.showProducts(p);
		
		
		
		}
		
		
		
		
		
	
}


