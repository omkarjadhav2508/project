package com.Ecom.project;

public class Ecom {

	
	//public void registerUser(String fname, String lname, String mob, String email );
	
	//public void showProducts();
	
	//public void addProducts(int pid, int qty);
	
	//public double showPrice();
	
	//public int addToCart(int pid);
	
	//public void getRegisterdUser();
	
	
	
}
