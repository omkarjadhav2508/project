package com.Ecom.project;

public class Cart {

	int id;
	int qty;
	int price;
	String description;
	
	public Cart(int id, int qty, int price, String description) {
		super();
		this.id = id;
		this.qty = qty;
		this.price = price;
		this.description = description;
	}
	
	

}
