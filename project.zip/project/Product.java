package com.Ecom.project;

import java.sql.*;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Scanner;
import java.util.Set;

class Product {
	// ------------------------showPrice()-----------------------------
	Connection consp = null;
	PreparedStatement pssp = null;
	ResultSet rssp = null;

	// ------------------------showPrice()---------------------------

	// ------------------------addToCart()---------------------------

	Scanner scanner = new Scanner(System.in);
	int totalPrice = 0;
	int q1, q2, q3, q4, q5, q6, q7, q8, q9, q10;

	LinkedHashMap<Integer, Integer> hmatc = new LinkedHashMap<Integer, Integer>();

	// ------------------------addToCart()---------------------------

	// ------------------------getPrice()----------------------------
	LinkedHashMap<Integer, Integer> hmgp = new LinkedHashMap<Integer, Integer>();
	Connection congp = null;
	PreparedStatement psgp = null;
	ResultSet rsgp = null;
	// ------------------------getPrice()----------------------------

	// ------------------------getBill()----------------------------

	LinkedHashMap<Integer, String> hmpdsc = new LinkedHashMap<Integer, String>();
	Connection congb = null;
	PreparedStatement psgb = null;
	ResultSet rsgb = null;

	// ------------------------getBill()----------------------------

	// ------------------------updateQty()-----------------------
	/*int [] q = new int[10]; //stored original qty from table
	int[] uq= new int[10];   //updated qty as per user adds to cart
	*/
	int qi1 ;
	int qi2 ;
	int qi3 ;
	int qi4 ;
	int qi5 ;
	int qi6 ;
	int qi7 ;
	int qi8 ;
	int qi9 ;
	int qi10;
	//uq[1]=qi1;
	/*
	PreparedStatement psuq = null;
	PreparedStatement psuq1 = null;
	ResultSet rsuq = null;
*/
	// ------------------------updateQty()-----------------------

	public void showProducts(Product p) throws SQLException {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			consp = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecom", "root", "Root");
			pssp = consp.prepareStatement("select * from product");

			rssp = pssp.executeQuery();
			System.out.println("======================");
			System.out.println("Available products are");
			System.out.println("======================");
			System.out.println();
			while (rssp.next()) {
				System.out.println("Product id>>>" + rssp.getInt(1) + "  ");
				System.out.println("Product Description>>>" + rssp.getString(2));
				System.out.println("Product Price>>>" + rssp.getInt(3));
				System.out.println("Product Name>>>" + rssp.getString(4));
				System.out.println("Product quantity>>>" + rssp.getInt(5));
				System.out.println("*******************************");
			}
			p.addToCart(p);

		}

		catch (Exception e) {
			e.printStackTrace();
		} finally {
			consp.close();
			pssp.close();
			rssp.close();
		}
	}

	public void addToCart(Product p) throws SQLException {
		Product product = new Product();
		while (true) {
			System.out.println("Please enter the product id to add it to the cart ");
			int pid = scanner.nextInt();
			switch (pid) {
			case 1:
				System.out.println("Enter quantity of LCD ");
				q1 = scanner.nextInt();
				hmatc.put(pid, q1);
				System.out.println("price for LCD with quantity " + q1 + " is " + (product.getPrice(pid) * q1));
				totalPrice += (product.getPrice(pid) * q1);
				qi1 = qi1 - q1;
				break;
			case 2:
				System.out.println("Enter quantity of Printer");
				q2 = scanner.nextInt();
				hmatc.put(pid, q2);
				System.out.println("price for printer with quantity " + q2 + " is " + (product.getPrice(pid) * q2));
				totalPrice += (product.getPrice(pid) * q2);
				qi2 = qi2 - q2;
				break;
			case 3:
				System.out.println("Enter quantity of mouse ");
				q3 = scanner.nextInt();
				hmatc.put(pid, q3);
				System.out.println("price for mouse with quantity " + q3 + " is " + (product.getPrice(pid) * q3));
				totalPrice += (product.getPrice(pid) * q3);
				qi3 = qi3 - q3;
				break;
			case 4:
				System.out.println("Enter quantity of scanner");
				q4 = scanner.nextInt();
				hmatc.put(pid, q4);
				System.out.println("price for scanner with quantity " + q4 + " is " + (product.getPrice(pid) * q4));
				totalPrice += (product.getPrice(pid) * q4);
				qi4 = qi4 - q4;
				break;
			case 5:
				System.out.println("Enter quantity of Pendrive");
				q5 = scanner.nextInt();
				hmatc.put(pid, q5);
				System.out.println("price for Pendrive with quantity " + q5 + " is" + (product.getPrice(pid) * q5));
				totalPrice += (product.getPrice(pid) * q5);
				qi5 = qi5 - q5;
				break;
			case 6:
				System.out.println("Enter quantity of Headphones ");
				q6 = scanner.nextInt();
				hmatc.put(pid, q6);
				System.out.println("price for headphones with quantity " + q6 + " is " + (product.getPrice(pid) * q6));
				totalPrice += (product.getPrice(pid) * q6);
				qi6 = qi6 - q6;
				break;
			case 7:
				System.out.println("Enter quantity of Speaker");
				q7 = scanner.nextInt();
				hmatc.put(pid, q7);
				System.out.println("price for speaker with quantity " + q7 + " is " + (product.getPrice(pid) * q7));
				totalPrice += (product.getPrice(pid) * q7);
				qi7 = qi7 - q7;
				break;
			case 8:
				System.out.println("Enter quantity of KeyBoard ");
				q8 = scanner.nextInt();
				hmatc.put(pid, q8);
				System.out.println("price for keyboard with quantity " + q8 + " is " + (product.getPrice(pid) * q8));
				totalPrice += (product.getPrice(pid) * q8);
				qi8 = qi8 - q8;
				break;
			case 9:
				System.out.println("Enter quantity of Hard Disk");
				q9 = scanner.nextInt();
				hmatc.put(pid, q9);
				System.out.println("price for hard disk with quantity " + q9 + " is " + (product.getPrice(pid) * q9));
				totalPrice += (product.getPrice(pid) * q9);
				qi9 = qi9 - q9;
				break;
			case 10:
				System.out.println("Enter quantity of laptop ");
				q10 = scanner.nextInt();
				hmatc.put(pid, q10);
				System.out.println("price for laptop with quantity " + q10 + " is " + (product.getPrice(pid) * q10));
				totalPrice += (product.getPrice(pid) * q10);
				qi10 = qi10 - q10;
				break;
			}
			System.out.println("Total price to be paid is " + totalPrice + " Rupees Only");
			System.out.println("Do you want to add more items y/n");
			String str = scanner.next();
			if (str.equals("n")) {
				break;
			}
		}
		
		p.getBill(p);
	}

	public int getPrice(int pid) throws SQLException { // id(key) and price(value)

		try {
			Class.forName("com.mysql.jdbc.Driver");
			congp = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecom", "root", "Root");
			psgp = congp.prepareStatement("select pid,price from product");
			rsgp = psgp.executeQuery();
			while (rsgp.next()) {
				hmgp.put(rsgp.getInt(1), rsgp.getInt(2));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			congp.close();
			psgp.close();
			rsgp.close();
		}
		return (hmgp.get(pid));
	}

	public void getBill(Product p) throws SQLException {

		try {
			congb = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecom", "root", "Root");
			psgb = congb.prepareStatement("select pid,description from product");
			rsgb = psgb.executeQuery();
			System.out.println("===================================================");
			System.out.println("id" + "    " + "Description    " + "          " + "  Quantity   " + "    " + "price");
			while (rsgb.next()) {
				hmpdsc.put(rsgb.getInt(1), rsgb.getString(2));
			}

			Set s = hmatc.keySet();
			Iterator itr = s.iterator();
			// System.out.println("selected items " + hmatc);

			while (itr.hasNext()) {


				Object obj = itr.next();
				String str = obj.toString();
				int id = Integer.parseInt(str);
				
				System.out.print(obj + "    ");
				System.out.print(hmpdsc.get(obj) + "                ");
				System.out.print(hmatc.get(obj) + "             ");
				System.out.println(hmatc.get(obj) * (p.getPrice((id))));
				

			}
			System.out.println("Total Amount to be paid is" + totalPrice);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			congb.close();
			psgb.close();
			rsgb.close();
			
		}
	}

	}
